#include <stdio.h>

void getOption(int* selection){
	scanf("%d", selection);
}

void getCar(int* selection){
	int a;
	int b;
	scanf("%d", selection);
}
